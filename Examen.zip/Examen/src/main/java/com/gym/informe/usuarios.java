package com.gym.informe;

import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.gym.datos.Conexion;
import com.gym.informe.*;

public class usuarios {
		
	
	private String nombre;
	private int edad;
	private double estatura;
	private double peso;
	private String imc;
	private int t_bicep;
	private int t_antebrazo;
	private int t_pecho;
	private int t_muslo;
	private int t_cintura;
	private int id;
	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public double getEstatura() {
		return estatura;
	}


	public void setEstatura(double estatura) {
		this.estatura = estatura;
	}


	public double getPeso() {
		return peso;
	}


	public void setPeso(double peso) {
		this.peso = peso;
	}


	public String getImc() {
		return imc;
	}


	public void setImc(String imc) {
		this.imc = imc;
	}


	public int getT_bicep() {
		return t_bicep;
	}


	public void setT_bicep(int t_bicep) {
		this.t_bicep = t_bicep;
	}


	public int getT_antebrazo() {
		return t_antebrazo;
	}


	public void setT_antebrazo(int t_antebrazo) {
		this.t_antebrazo = t_antebrazo;
	}


	public int getT_pecho() {
		return t_pecho;
	}


	public void setT_pecho(int t_pecho) {
		this.t_pecho = t_pecho;
	}


	public int getT_muslo() {
		return t_muslo;
	}


	public void setT_muslo(int t_muslo) {
		this.t_muslo = t_muslo;
	}


	public int getT_cintura() {
		return t_cintura;
	}


	public void setT_cintura(int t_cintura) {
		this.t_cintura = t_cintura;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}




	public int getEdad() {
		return edad;
	}


	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public usuarios()  {
		setId(0);
		setNombre("");
		setPeso(0);
		setT_bicep(0);
		setT_antebrazo(0);
		setT_pecho(0);
		setT_muslo(0);
		setT_cintura(0);
	}
	
	public usuarios (int cod, String nom, double peso, int bi,int an,int pe,int mu,int ci) {
		setId(cod);
		setNombre(nom);
		setPeso(peso);
		setT_bicep(bi);
		setT_antebrazo(an);
		setT_pecho(pe);
		setT_muslo(mu);
		setT_cintura(ci);
	}

	public boolean modificarUsuario(usuarios usu) {
		boolean agregado=false;
		Conexion obj= new Conexion();
		String sql = "UPDATE usuarios SET peso='"+usu.getPeso() + "',t_bicep = '" +usu.getT_bicep()+"',"
		+"t_antebrazo = '" + usu.getT_antebrazo() + "t_pecho = '" + usu.getT_pecho() +"t_muslo = '" + usu.getT_muslo() +"t_cintura = '" + usu.getT_cintura() +"' WHERE \"id_cliente\"='" + usu.getId() +"'";
		try {
		obj.Ejecutar(sql);
		agregado = true;
		} catch (Exception e) {
			agregado = false;
		}
		return agregado;
	}
	
	public String consultarUsuarios()
	{
		String sql="SELECT * FROM usuario ORDER BY id_cliente";
		Conexion con=new Conexion();
		String tabla="<table style=\"border:1px solid black;margin-left:auto;margin-right:auto;text-align:center;background-color:#FFFFFF;\"><th style=\"border:1px solid black;\">ID</th><th style=\"border:1px solid black;\">Nombre</th><th style=\"border:1px solid black;\">Edad</th><th style=\"border:1px solid black;\">Estatura</th><th style=\"border:1px solid black;\">Peso</th><th style=\"border:1px solid black;\">IMC</th><th style=\"border:1px solid black;\">T_bicep</th><th style=\"border:1px solid black;\">T_antebrazo</th><th style=\"border:1px solid black;\">T_pecho</th><th style=\"border:1px solid black;\">T_muslo</th><th style=\"border:1px solid black;\">T_cintura</th><th style=\"border:1px solid black;\">Modificar</th><th style=\"border:1px solid black;\">Eliminar</th>";
		ResultSet rs=null;
		rs=con.Consulta(sql);
		try {
			while(rs.next())
			{
				tabla+="<tr><td style=\"border:1px solid black;\">"+rs.getInt(1)+"</td>"
						+ "<td style=\"border:1px solid black;\" >"+rs.getString(2)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(3)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getDouble(4)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getDouble(5)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getString(6)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(7)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(8)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(9)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(10)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(11)+"</td>"
						+ "<td style=\"border:1px solid black;\"> <a href= modificar.jsp?cod=" + rs.getInt(1) + "><pre style=\"text-align:center\">Modificar</pre></a></td>"
							+ "<td style=\"border:1px solid black;\"> <a href= eliminarUsuario.jsp?cod=" + rs.getInt(1) + " \"><pre style=\"textalign: center\">Eliminar</pre></a></td>"
						+ "</td></tr>";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.print(e.getMessage());
		}
		tabla+="</table>";
		return tabla;
	}
	
	
	public int consultarmaxID()
	{
		String sql="SELECT MAX(id_cliente) FROM usuario";
		Conexion con=new Conexion();
		int max=0;
		ResultSet rs=null;
		rs=con.Consulta(sql);
		try {
			while(rs.next())
			{
				max=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.print(e.getMessage());
		}
		return max;
	}
	
	
	
	public String ingresarUsuario(int id_usuario,String nombre, int edad,double estatura, double peso, String imc,int t_bicep,int t_antebrazo,int t_pecho,int t_muslo,int t_cintura)
	{
		String result="";
		Conexion con=new Conexion();
		PreparedStatement pr=null;
		String sql="INSERT INTO usuario (id_cliente,nombre_cliente,edad,"
				+ "estatura,peso,imc,t_bicep,t_antebrazo,t_pecho,t_muslo,t_cintura) "
				+ "VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		try{
			pr=con.getConexion().prepareStatement(sql);
			pr.setInt(1,id_usuario);
			pr.setString(2, nombre);
			pr.setInt(3, edad);
			pr.setDouble(4,estatura);	
			pr.setDouble(5,peso);	
			pr.setString(6, imc);
			pr.setInt(7, t_bicep);
			pr.setInt(8, t_antebrazo);
			pr.setInt(9, t_pecho);
			pr.setInt(10, t_muslo);
			pr.setInt(11, t_cintura);

			if(pr.executeUpdate()==1)
			{
				result="Inserción correcta";
			}
			else
			{
				result="Error en inserción";
			}
		}
		catch(Exception ex)
		{
			result=ex.getMessage();
		}
		finally
		{
			try
			{
				pr.close();
				con.getConexion().close();
			}
			catch(Exception ex)
			{
				System.out.print(ex.getMessage());
			}
		}
		return result;
	}
	
	public String mostrarUsuarios()
	{
		String combo="<select name=cmbUsuarios>";
		String sql="SELECT * FROM usuario";
		ResultSet rs=null;
		Conexion con=new Conexion();
		try
		{
			rs=con.Consulta(sql);
			while(rs.next())
			{
				combo+="<option value="+rs.getString(2)+ ">"+rs.getString(2)+"</option>";
			}
			combo+="</select>";
		}
		catch(SQLException e)
		{
			System.out.print(e.getMessage());
		}
		return combo;
	}
	
	public boolean EliminarUsuario(int cod) {
		boolean f = false;
		Conexion con = new Conexion();
		String sql = "delete from usuario where id_cliente='" + cod + "'";
		try {
			con.Ejecutar(sql);
			f = true;
		} catch (Exception e) {
			f = false;
		}
		return f;
	}
	
	
	public void ConsulEditarUsuario(int cod) {
		Conexion obj = new Conexion();
		ResultSet rs = null;
		
		String sql = "SELECT id_cliente,nombre_cliente,peso,t_bicep,t_antebrazo,t_pecho,t_muslo,t_cintura FROM usuario where id_cliente = '" + cod + "'";
		
		try {
			rs = obj.Consulta(sql);
			while (rs.next()) {
				setId(rs.getInt(1));
				setNombre(rs.getString(2));
				setPeso(rs.getDouble(3));
				setT_bicep(rs.getInt(4));
				setT_antebrazo(rs.getInt(5));
				setT_pecho(rs.getInt(6));
				setT_muslo(rs.getInt(7));
				setT_cintura(rs.getInt(8));
			}
		} catch(Exception e) {
			
		}
	}

	
}

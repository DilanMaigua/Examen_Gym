package com.gym.informe;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.gym.datos.Conexion;

public class informe {
	private String Recomendacion;
	private String Analisis;
	public String getRecomendacion() {
		return Recomendacion;
	}
	public void setRecomendacion(String recomendacion) {
		Recomendacion = recomendacion;
	}
	public String getAnalisis() {
		return Analisis;
	}
	public void setAnalisis(String analisis) {
		Analisis = analisis;
	}
	
	public String ingresarInforme(String nombre,String desc, String recomendacion, String analisis)
	{
		String result="";
		Conexion con=new Conexion();
		PreparedStatement pr=null;
		String sql="INSERT INTO informe (nombre_cliente,descripcion,"
				+ "recomendacion,analisis) "
				+ "VALUES(?,?,?,?)";
		try{
			pr=con.getConexion().prepareStatement(sql);
			pr.setString(1, nombre);
			pr.setString(2, desc);
			pr.setString(3, recomendacion);
			pr.setString(4, analisis);
		
			if(pr.executeUpdate()==1)
			{
				result="Inserción correcta";
			}
			else
			{
				result="Error en inserción";
			}
		}
		catch(Exception ex)
		{
			result=ex.getMessage();
		}
		finally
		{
			try
			{
				pr.close();
				con.getConexion().close();
			}
			catch(Exception ex)
			{
				System.out.print(ex.getMessage());
			}
		}
		return result;
	}
	
	public String consultarInforme()
	{
		String sql="SELECT * FROM informe ORDER BY nombre_cliente";
		Conexion con=new Conexion();
		String tabla="<table style=\"border:1px solid black;margin-left:auto;margin-right:auto;text-align:center;background-color:#FFFFFF;\"><th style=\"border:1px solid black;\">Nombre</th><th style=\"border:1px solid black;\">Programa</th><th style=\"border:1px solid black;\">Recomendacion</th><th style=\"border:1px solid black;\">Analisis</th>";
		ResultSet rs=null;
		rs=con.Consulta(sql);
		try {
			while(rs.next())
			{
				tabla+="<tr><td style=\"border:1px solid black;\">"+rs.getString(1)+"</td>"
						+ "<td style=\"border:1px solid black;\" >"+rs.getString(2)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getString(3)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getString(4)+"</td>"
						+ "</td></tr>";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.print(e.getMessage());
		}
		tabla+="</table>";
		return tabla;
	}
	
}

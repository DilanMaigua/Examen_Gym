package com.gym.informe;

import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.gym.datos.Conexion;


public class programa {
	private String desc;
	private String ejer1;
	private String ejer2;
	private String ejer3;
	private String ejer4;
	private String ejer5;
	private int peso1;
	private int peso2;
	private int peso3;
	private int peso4;
	private int peso5;
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getEjer1() {
		return ejer1;
	}
	public void setEjer1(String ejer1) {
		this.ejer1 = ejer1;
	}
	public String getEjer2() {
		return ejer2;
	}
	public void setEjer2(String ejer2) {
		this.ejer2 = ejer2;
	}
	public String getEjer3() {
		return ejer3;
	}
	public void setEjer3(String ejer3) {
		this.ejer3 = ejer3;
	}
	public String getEjer4() {
		return ejer4;
	}
	public void setEjer4(String ejer4) {
		this.ejer4 = ejer4;
	}
	public String getEjer5() {
		return ejer5;
	}
	public void setEjer5(String ejer5) {
		this.ejer5 = ejer5;
	}
	public int getPeso1() {
		return peso1;
	}
	public void setPeso1(int peso1) {
		this.peso1 = peso1;
	}
	public int getPeso2() {
		return peso2;
	}
	public void setPeso2(int peso2) {
		this.peso2 = peso2;
	}
	public int getPeso3() {
		return peso3;
	}
	public void setPeso3(int peso3) {
		this.peso3 = peso3;
	}
	public int getPeso4() {
		return peso4;
	}
	public void setPeso4(int peso4) {
		this.peso4 = peso4;
	}
	public int getPeso5() {
		return peso5;
	}
	public void setPeso5(int peso5) {
		this.peso5 = peso5;
	}
	
	public int consultarmaxID()
	{
		String sql="SELECT MAX(id_programa) FROM programa";
		Conexion con=new Conexion();
		int max=0;
		ResultSet rs=null;
		rs=con.Consulta(sql);
		try {
			while(rs.next())
			{
				max=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.print(e.getMessage());
		}
		return max;
	}
	
	
	public String consultarProgramas()
	{
		String sql="SELECT * FROM programa ORDER BY id_programa";
		Conexion con=new Conexion();
		String tabla="<table style=\"border:1px solid black;margin-left:auto;margin-right:auto;text-align:center;background-color:#FFFFFF;\"><th style=\"border:1px solid black;\">ID</th><th style=\"border:1px solid black;\">Descripcion</th><th style=\"border:1px solid black;\">Para</th><th style=\"border:1px solid black;\">Ejercicio 1</th><th style=\"border:1px solid black;\">Peso 1</th><th style=\"border:1px solid black;\">Ejercicio 2</th><th style=\"border:1px solid black;\">Peso 2</th><th style=\"border:1px solid black;\">Ejercicio 3</th><th style=\"border:1px solid black;\">Peso 3</th><th style=\"border:1px solid black;\">Ejercicio 4</th><th style=\"border:1px solid black;\">Peso 4</th><th style=\"border:1px solid black;\">Ejercicio 5</th><th style=\"border:1px solid black;\">Peso 5</th><th style=\"border:1px solid black;\">Eliminar</th>";
		ResultSet rs=null;
		rs=con.Consulta(sql);
		try {
			while(rs.next())
			{
				tabla+="<tr><td style=\"border:1px solid black;\">"+rs.getInt(1)+"</td>"
						+ "<td style=\"border:1px solid black;\" >"+rs.getString(2)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getString(13)+"</td>"
								+ "<td style=\"border:1px solid black;\">"+rs.getString(3)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(4)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getString(5)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(6)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getString(7)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(8)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getString(9)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(10)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getString(11)+"</td>"
						+ "<td style=\"border:1px solid black;\">"+rs.getInt(12)+"</td>"
						+ "<td style=\"border:1px solid black;\"> <a href= eliminarPrograma.jsp?cod=" + rs.getInt(1) + " \"><pre style=\"textalign: center\">Eliminar</pre></a></td>"
						+ "</td></tr>";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.print(e.getMessage());
		}
		tabla+="</table>";
		return tabla;
	}
	
	public String mostrarProgramas()
	{
		String combo="<select name=cmbPrograma>";
		String sql="SELECT * FROM programa";
		ResultSet rs=null;
		Conexion con=new Conexion();
		try
		{
			rs=con.Consulta(sql);
			while(rs.next())
			{
				combo+="<option value="+rs.getString(2)+ ">"+rs.getString(2)+"</option>";
			}
			combo+="</select>";
		}
		catch(SQLException e)
		{
			System.out.print(e.getMessage());
		}
		return combo;
	}
	
	public boolean EliminarPrograma(int cod) {
		boolean f = false;
		Conexion con = new Conexion();
		String sql = "delete from programa where id_programa='" + cod + "'";
		try {
			con.Ejecutar(sql);
			f = true;
		} catch (Exception e) {
			f = false;
		}
		return f;
	}
	
	public String ingresarPrograma(int id_pro,String desc,String e1, int p1,String e2, int p2,String e3, int p3,String e4, int p4,String e5, int p5,String nombre)
	{
		String result="";
		Conexion con=new Conexion();
		PreparedStatement pr=null;
		String sql="INSERT INTO programa (id_programa,descripcion,ejercicio1,peso1,"
				+ "ejercicio2,peso2,ejercicio3,peso3,ejercicio4,peso4,ejercicio5,peso5,nombre_cliente) "
				+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try{
			pr=con.getConexion().prepareStatement(sql);
			pr.setInt(1,id_pro);
			pr.setString(2, desc);
			pr.setString(3, e1);
			pr.setInt(4, p1);
			pr.setString(5, e2);
			pr.setInt(6, p2);
			pr.setString(7, e3);
			pr.setInt(8, p3);
			pr.setString(9, e4);
			pr.setInt(10, p4);
			pr.setString(11, e5);
			pr.setInt(12, p5);
			pr.setString(13, nombre);
			
			if(pr.executeUpdate()==1)
			{
				result="Inserción correcta";
			}
			else
			{
				result="Error en inserción";
			}
		}
		catch(Exception ex)
		{
			result=ex.getMessage();
		}
		finally
		{
			try
			{
				pr.close();
				con.getConexion().close();
			}
			catch(Exception ex)
			{
				System.out.print(ex.getMessage());
			}
		}
		return result;
	}
	
}
